package com.microemprende.cl.micro_emprende.model;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "venta")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String productoVenta;

    @Column(nullable = false)
    private LocalDate fechaVenta;

    @Column(nullable = false)
    private LocalTime horaVenta;

    @Column(nullable = false)
    private Integer costo;

   
    @ManyToOne
    @JoinColumn(name = "vendedor_id")
    private Vendedor vendedor;

  
    @ManyToOne
    @JoinColumn(name = "duenio_id")
    private Duenio duenio;
}