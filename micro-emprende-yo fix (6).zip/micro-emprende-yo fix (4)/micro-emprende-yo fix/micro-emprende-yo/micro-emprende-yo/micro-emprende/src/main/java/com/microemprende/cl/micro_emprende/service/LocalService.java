package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Local;
import com.microemprende.cl.micro_emprende.repository.LocalRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class LocalService {

    @Autowired
    private LocalRepository localRepository;

    public List<Local> findAll() {
        return localRepository.findAll();
    }

    public Local findById(Long id) {
        Optional<Local> localOptional = localRepository.findById(id); 
        if (localOptional.isPresent()) {
            return localOptional.get(); 
        } else {
            throw new RuntimeException("Local no disponible o inexistente"); 
        }
    }

    public Local save(Local local) {
        return localRepository.save(local);
    }

    public void delete(Long id) {
        localRepository.deleteById(id);
    }

    public Local patchLocal(Long id, Local parcialLocal){
        Optional<Local> localOptional = localRepository.findById(id);
        if (localOptional.isPresent()) {
            
            Local localToUpdate = localOptional.get();
            
            if (parcialLocal.getNombre() != null) {
                localToUpdate.setNombre(parcialLocal.getNombre());    
            }

            if (parcialLocal.getDireccion() != null) {
                localToUpdate.setDireccion(parcialLocal.getDireccion());
            }

            if (parcialLocal.getComuna() != null) {
                localToUpdate.setComuna(parcialLocal.getComuna());
            }

            if (parcialLocal.getHorarioAtencion() != null) {
                localToUpdate.setHorarioAtencion(parcialLocal.getHorarioAtencion());
            }

            if (parcialLocal.getHorarioCierre() != null) {
                localToUpdate.setHorarioCierre(parcialLocal.getHorarioCierre());
            }

            return localRepository.save(localToUpdate);
        } else {
            return null; 
        }
    }
}
