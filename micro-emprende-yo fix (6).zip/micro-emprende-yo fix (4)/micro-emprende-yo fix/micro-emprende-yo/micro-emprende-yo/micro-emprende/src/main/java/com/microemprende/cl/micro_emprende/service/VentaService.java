package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Venta;
import com.microemprende.cl.micro_emprende.repository.VentaRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    public List<Venta> findAll() {
        return ventaRepository.findAll();
    }

    public Venta findById(Long id) {
        Optional<Venta> ventaOptional = ventaRepository.findById(id); 
        if (ventaOptional.isPresent()) {
            return ventaOptional.get(); 
        } else {
            throw new RuntimeException("no disponible o inexistente"); 
        }
    }

    public Venta save(Venta venta) {
        return ventaRepository.save(venta);
    }

    public void delete(Long id) {
        ventaRepository.deleteById(id);
    }

    public Venta patchVenta(Long id, Venta parcialVenta){
        Optional<Venta> ventaOptional = ventaRepository.findById(id);
        if (ventaOptional.isPresent()) {
            
            Venta ventaToUpdate = ventaOptional.get();
            
            if (parcialVenta.getProductoVenta() != null) {
                ventaToUpdate.setProductoVenta(parcialVenta.getProductoVenta());    
            }

            if(parcialVenta.getFechaVenta() != null) {
                ventaToUpdate.setFechaVenta(parcialVenta.getFechaVenta());
            }

            if(parcialVenta.getHoraVenta() != null) {
                ventaToUpdate.setHoraVenta(parcialVenta.getHoraVenta());
            }

            if(parcialVenta.getCosto() != null) {
                ventaToUpdate.setCosto(parcialVenta.getCosto());
            }

            return ventaRepository.save(ventaToUpdate);
        } else {
            return null; 
        }

     }

    

}
