package com.microemprende.cl.micro_emprende.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microemprende.cl.micro_emprende.model.Vendedor;
import com.microemprende.cl.micro_emprende.service.VendedorService;

@RestController
@RequestMapping("/api/v1/vendedor")
public class VendedorController {
    @Autowired
    private VendedorService vendedorService;

    @GetMapping
    public ResponseEntity<List<Vendedor>> listar(){
        List <Vendedor> vendedores = vendedorService.findAll();
        if(vendedores.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(vendedores);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vendedor> buscar(@PathVariable Long id){
        try{
            Vendedor vendedor = vendedorService.findById(id);
            return ResponseEntity.ok(vendedor);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Vendedor> guardar(@RequestBody Vendedor vendedor) {
        Vendedor vendedorNuevo = vendedorService.save(vendedor);
        return ResponseEntity.status(HttpStatus.CREATED).body(vendedorNuevo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Vendedor> actualizar(@PathVariable Long id, @RequestBody Vendedor vendedor){
        try{
            vendedorService.save(vendedor);
            return ResponseEntity.ok(vendedor);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Vendedor> patchVendedor(@PathVariable Long id, @RequestBody Vendedor partialVendedor) {
        try {
            Vendedor updatedVendedor = vendedorService.patchVendedor(id, partialVendedor);
            return ResponseEntity.ok(updatedVendedor);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            vendedorService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }


}
