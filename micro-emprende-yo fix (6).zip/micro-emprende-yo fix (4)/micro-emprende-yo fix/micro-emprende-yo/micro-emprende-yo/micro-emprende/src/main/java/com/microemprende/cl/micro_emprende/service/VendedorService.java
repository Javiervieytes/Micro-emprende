package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Vendedor;
import com.microemprende.cl.micro_emprende.repository.VendedorRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class VendedorService {

    @Autowired
    private VendedorRepository vendedorRepository;

    public List<Vendedor> findAll() {
        return vendedorRepository.findAll();
    }

    public Vendedor findById(Long id) {
        Optional<Vendedor> vendedorOptional = vendedorRepository.findById(id); 
        if (vendedorOptional.isPresent()) {
            return vendedorOptional.get(); 
        } else {
            throw new RuntimeException("Producto no disponible o inexistente"); 
        }
    }

    public Vendedor save(Vendedor vendedor) {
        return vendedorRepository.save(vendedor);
    }

    public void delete(Long id) {
        vendedorRepository.deleteById(id);
    }

    public Vendedor patchVendedor(Long id, Vendedor parcialVendedor){
        Optional<Vendedor> vendedorOptional = vendedorRepository.findById(id);
        if (vendedorOptional.isPresent()) {
            
            Vendedor vendedorToUpdate = vendedorOptional.get();
            
            if (parcialVendedor.getRun() != null) {
                vendedorToUpdate.setRun(parcialVendedor.getRun());    
            }

            if(parcialVendedor.getNombre() != null) {
                vendedorToUpdate.setNombre(parcialVendedor.getNombre());
            }

            if(parcialVendedor.getHora_entrada() != null) {
                vendedorToUpdate.setHora_entrada(parcialVendedor.getHora_entrada());
            }

            if(parcialVendedor.getHora_salida() != null) {
                vendedorToUpdate.setHora_salida(parcialVendedor.getHora_salida());
            }

            return vendedorRepository.save(vendedorToUpdate);
        } else {
            return null; 
        }

     }

}
