package com.microemprende.cl.micro_emprende.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microemprende.cl.micro_emprende.model.Local;

@Repository
public interface LocalRepository extends JpaRepository<Local, Long>{

    List<Local> findByNombre(String nombre);

    Local findByDireccion(String direccion);

    Local findById(Integer id);

}
