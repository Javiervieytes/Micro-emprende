package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Cliente;
import com.microemprende.cl.micro_emprende.repository.ClienteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> findAll() {
        return clienteRepository.findAll();
    }

    public Cliente findById(Long id) {
        Optional<Cliente> clienteOptional = clienteRepository.findById(id); 
        if (clienteOptional.isPresent()) {
            return clienteOptional.get(); 
        } else {
            throw new RuntimeException("Producto no disponible o inexistente"); 
        }
    }

    public Cliente save(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public void delete(Long id) {
        clienteRepository.deleteById(id);
    }

    public Cliente patchCliente(Long id, Cliente parcialCliente){
        Optional<Cliente> clienteOptional = clienteRepository.findById(id);
        if (clienteOptional.isPresent()) {
            
            Cliente clienteToUpdate = clienteOptional.get();
            
            if (parcialCliente.getRun() != null) {
                clienteToUpdate.setRun(parcialCliente.getRun());    
            }

            if(parcialCliente.getNombre() != null) {
                clienteToUpdate.setNombre(parcialCliente.getNombre());
            }

            if(parcialCliente.getApellido() != null) {
                clienteToUpdate.setApellido(parcialCliente.getApellido());
            }

            if(parcialCliente.getFechaNacimiento() != null) {
                clienteToUpdate.setFechaNacimiento(parcialCliente.getFechaNacimiento());
            }

            if(parcialCliente.getCorreo() != null) {
                clienteToUpdate.setCorreo(parcialCliente.getCorreo());
            }

            return clienteRepository.save(clienteToUpdate);
        } else {
            return null; 
        }
    }

}
