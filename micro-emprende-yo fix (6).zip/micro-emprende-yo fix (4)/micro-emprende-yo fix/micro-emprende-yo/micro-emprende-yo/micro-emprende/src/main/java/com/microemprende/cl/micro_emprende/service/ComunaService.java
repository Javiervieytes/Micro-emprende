package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Comuna;
import com.microemprende.cl.micro_emprende.repository.ComunaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ComunaService {

    @Autowired
    private ComunaRepository comunaRepository;

    public List<Comuna> findAll() {
        return comunaRepository.findAll();
    }

    public Comuna findById(Long id) {
        Optional<Comuna> comunaOptional = comunaRepository.findById(id);
        if (comunaOptional.isPresent()) {
            return comunaOptional.get();
        } else {
            throw new RuntimeException("Comuna no disponible o inexistente");
        }
    }

    public Comuna save(Comuna comuna) {
        return comunaRepository.save(comuna);
    }

    public void delete(Long id) {
        comunaRepository.deleteById(id);
    }

    public Comuna patchComuna(Long id, Comuna parcialComuna) {
        Optional<Comuna> comunaOptional = comunaRepository.findById(id);
        if (comunaOptional.isPresent()) {

            Comuna comunaToUpdate = comunaOptional.get();

            if (parcialComuna.getNombre() != null) {
                comunaToUpdate.setNombre(parcialComuna.getNombre());
            }

            if (parcialComuna.getRegion() != null) {
                comunaToUpdate.setRegion(parcialComuna.getRegion());
            }

            return comunaRepository.save(comunaToUpdate);
        } else {
            return null;
        }
    }
}
