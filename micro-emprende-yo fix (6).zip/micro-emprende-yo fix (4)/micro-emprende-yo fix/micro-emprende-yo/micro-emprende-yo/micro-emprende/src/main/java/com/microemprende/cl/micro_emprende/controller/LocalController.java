package com.microemprende.cl.micro_emprende.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microemprende.cl.micro_emprende.model.Local;
import com.microemprende.cl.micro_emprende.service.LocalService;

@RestController
@RequestMapping("/api/v1/local")
public class LocalController {

    @Autowired
    private LocalService localService;

    @GetMapping
    public ResponseEntity<List<Local>> listar() {
        List<Local> locales = localService.findAll();
        if (locales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(locales);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Local> buscar(@PathVariable Long id) {
        try {
            Local local = localService.findById(id);
            return ResponseEntity.ok(local);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Local> guardar(@RequestBody Local local) {
        Local nuevoLocal = localService.save(local);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoLocal);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Local> actualizar(@PathVariable Long id, @RequestBody Local local) {
        try {
            localService.save(local);
            return ResponseEntity.ok(local);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Local> patchLocal(@PathVariable Long id, @RequestBody Local partialLocal) {
        try {
            Local localActualizado = localService.patchLocal(id, partialLocal);
            return ResponseEntity.ok(localActualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            localService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
