package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.BoletaOFactura;
import com.microemprende.cl.micro_emprende.repository.BoletaOFacturaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BoletaOFacturaService {

    @Autowired
    private BoletaOFacturaRepository boletaOFacturaRepository;

    public List<BoletaOFactura> findAll() {
        return boletaOFacturaRepository.findAll();
    }

    public BoletaOFactura findById(Long id) {
        Optional<BoletaOFactura> optional = boletaOFacturaRepository.findById(id); 
        if (optional.isPresent()) {
            return optional.get(); 
        } else {
            throw new RuntimeException("Boleta o factura no disponible o inexistente"); 
        }
    }

    public BoletaOFactura save(BoletaOFactura boletaOFactura) {
        return boletaOFacturaRepository.save(boletaOFactura);
    }

    public void delete(Long id) {
        boletaOFacturaRepository.deleteById(id);
    }

    public BoletaOFactura patchBoletaOFactura(Long id, BoletaOFactura parcial) {
        Optional<BoletaOFactura> optional = boletaOFacturaRepository.findById(id);
        if (optional.isPresent()) {
            BoletaOFactura toUpdate = optional.get();

            if (parcial.getTipo() != null) {
                toUpdate.setTipo(parcial.getTipo());
            }

            if (parcial.getFechaEmision() != null) {
                toUpdate.setFechaEmision(parcial.getFechaEmision());
            }

            if (parcial.getMontoTotal() != null) {
                toUpdate.setMontoTotal(parcial.getMontoTotal());
            }

            if (parcial.getMetodoPago() != null) {
                toUpdate.setMetodoPago(parcial.getMetodoPago());
            }

            return boletaOFacturaRepository.save(toUpdate);
        } else {
            return null; 
        }
    }
}
