package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Producto;
import com.microemprende.cl.micro_emprende.repository.ProductoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductoService {


    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> findAll() {
        return productoRepository.findAll();
    }

    public Producto findById(Long id) {
        Optional<Producto> productoOptional = productoRepository.findById(id); 
        if (productoOptional.isPresent()) {
            return productoOptional.get(); 
        } else {
            throw new RuntimeException("Producto no disponible o inexistente"); 
        }
    }

    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }

    public void delete(Long id) {
        productoRepository.deleteById(id);
    }

    public Producto patchProducto(Long id, Producto parcialProducto){
        Optional<Producto> productoOptional = productoRepository.findById(id);
        if (productoOptional.isPresent()) {
            
            Producto productoToUpdate = productoOptional.get();
            
            if (parcialProducto.getProducto() != null) {
                productoToUpdate.setProducto(parcialProducto.getProducto());    
            }

            if(parcialProducto.getDescripcion() != null) {
                productoToUpdate.setDescripcion(parcialProducto.getDescripcion());
            }

            if(parcialProducto.getCategoria() != null) {
                productoToUpdate.setCategoria(parcialProducto.getCategoria());
            }

            if(parcialProducto.getCosto() != null) {
                productoToUpdate.setCosto(parcialProducto.getCosto());
            }

            if(parcialProducto.getStockProducto() != null) {
                productoToUpdate.setStockProducto(parcialProducto.getStockProducto());
            }

            return productoRepository.save(productoToUpdate);
        } else {
            return null; 
        }

     }

    
}
