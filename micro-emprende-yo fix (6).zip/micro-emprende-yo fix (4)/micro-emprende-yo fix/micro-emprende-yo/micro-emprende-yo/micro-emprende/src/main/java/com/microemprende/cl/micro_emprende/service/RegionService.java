package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Region;
import com.microemprende.cl.micro_emprende.repository.RegionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class RegionService {

    @Autowired
    private RegionRepository regionRepository;

    public List<Region> findAll() {
        return regionRepository.findAll();
    }

    public Region findById(Long id) {
        Optional<Region> regionOptional = regionRepository.findById(id); 
        if (regionOptional.isPresent()) {
            return regionOptional.get(); 
        } else {
            throw new RuntimeException("Región no disponible o inexistente"); 
        }
    }

    public Region save(Region region) {
        return regionRepository.save(region);
    }

    public void delete(Long id) {
        regionRepository.deleteById(id);
    }

    public Region patchRegion(Long id, Region parcialRegion) {
        Optional<Region> regionOptional = regionRepository.findById(id);
        if (regionOptional.isPresent()) {
            Region regionToUpdate = regionOptional.get();

            if (parcialRegion.getNombre() != null) {
                regionToUpdate.setNombre(parcialRegion.getNombre());
            }

          
            return regionRepository.save(regionToUpdate);
        } else {
            return null;
        }
    }
}
