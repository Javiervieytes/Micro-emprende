package com.microemprende.cl.micro_emprende;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroEmprendeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroEmprendeApplication.class, args);
	}

}
