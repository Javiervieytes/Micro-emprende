package com.microemprende.cl.micro_emprende.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microemprende.cl.micro_emprende.model.Duenio;
import com.microemprende.cl.micro_emprende.service.DuenioService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/duenios")
public class DuenioController {

    @Autowired
    private DuenioService duenioService;

    @GetMapping
    public ResponseEntity<List<Duenio>> listar(){
        List <Duenio> duenios = duenioService.findAll();
        if(duenios.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(duenios);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Duenio> buscar(@PathVariable Long id){
        try{
            Duenio duenio = duenioService.findById(id);
            return ResponseEntity.ok(duenio);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Duenio> guardar(@RequestBody Duenio duenio) {
        Duenio duenioNuevo = duenioService.save(duenio);
        return ResponseEntity.status(HttpStatus.CREATED).body(duenioNuevo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Duenio> actualizar(@PathVariable Long id, @RequestBody Duenio duenio){
        try{
            duenioService.save(duenio);
            return ResponseEntity.ok(duenio);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Duenio> patchDuenio(@PathVariable Long id, @RequestBody Duenio partialDuenio) {
        try {
            Duenio updatedDuenio = duenioService.patchDuenio(id, partialDuenio);
            return ResponseEntity.ok(updatedDuenio);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            duenioService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

}
