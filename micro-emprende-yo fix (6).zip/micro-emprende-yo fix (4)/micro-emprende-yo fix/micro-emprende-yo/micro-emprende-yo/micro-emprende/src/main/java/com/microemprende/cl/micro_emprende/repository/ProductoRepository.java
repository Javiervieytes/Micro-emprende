package com.microemprende.cl.micro_emprende.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microemprende.cl.micro_emprende.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{

    List<Producto> findByCategoria(String categoria);

    Producto findByProducto(String producto);

    Producto findById(Integer id);

}
