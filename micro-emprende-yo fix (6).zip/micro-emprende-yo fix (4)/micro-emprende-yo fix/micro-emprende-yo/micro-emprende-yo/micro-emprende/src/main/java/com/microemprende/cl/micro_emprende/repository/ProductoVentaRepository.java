package com.microemprende.cl.micro_emprende.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microemprende.cl.micro_emprende.model.ProductoVenta;

@Repository
public interface ProductoVentaRepository extends JpaRepository<ProductoVenta, Long> {

    List<ProductoVenta> findByVentaId(Long ventaId);

    List<ProductoVenta> findByProductoId(Long productoId);

    List<ProductoVenta> findByCantidad(Integer cantidad); 
}
