package com.microemprende.cl.micro_emprende.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microemprende.cl.micro_emprende.model.Region;

@Repository
public interface RegionRepository extends JpaRepository<Region, Long> {

    List<Region> findByNombre(String nombre);

}
