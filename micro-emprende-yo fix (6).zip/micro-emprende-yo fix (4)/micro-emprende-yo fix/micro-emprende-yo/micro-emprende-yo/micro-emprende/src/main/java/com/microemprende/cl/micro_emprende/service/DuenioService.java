package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Duenio;
import com.microemprende.cl.micro_emprende.repository.DuenioRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class DuenioService {

    @Autowired
    private DuenioRepository duenioRepository;

    public List<Duenio> findAll() {
        return duenioRepository.findAll();
    }

    public Duenio findById(Long id) {
        Optional<Duenio> duenioOptional = duenioRepository.findById(id);
        if (duenioOptional.isPresent()) {
            return duenioOptional.get();
        } else {
            throw new RuntimeException("Dueño no disponible o inexistente");
        }
    }

    public Duenio save(Duenio duenio) {
        return duenioRepository.save(duenio);
    }

    public void delete(Long id) {
        duenioRepository.deleteById(id);
    }

    public Duenio patchDuenio(Long id, Duenio parcialDuenio) {
        Optional<Duenio> duenioOptional = duenioRepository.findById(id);
        if (duenioOptional.isPresent()) {
            Duenio duenioToUpdate = duenioOptional.get();

            if (parcialDuenio.getRun() != null) {
                duenioToUpdate.setRun(parcialDuenio.getRun());
            }

            if (parcialDuenio.getNombre() != null) {
                duenioToUpdate.setNombre(parcialDuenio.getNombre());
            }

            if (parcialDuenio.getNombre() != null) {
                duenioToUpdate.setNombre(parcialDuenio.getNombre());
            }

            if (parcialDuenio.getApellido() != null) {
                duenioToUpdate.setApellido(parcialDuenio.getApellido());
            }

            return duenioRepository.save(duenioToUpdate);
        } else {
            throw new RuntimeException("Dueño no encontrado");
        }
    }
}

