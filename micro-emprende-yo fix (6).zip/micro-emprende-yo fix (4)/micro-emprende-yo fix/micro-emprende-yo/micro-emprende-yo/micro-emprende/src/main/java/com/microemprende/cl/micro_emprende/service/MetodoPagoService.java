package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.MetodoPago;
import com.microemprende.cl.micro_emprende.repository.MetodoPagoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class MetodoPagoService {

    @Autowired
    private MetodoPagoRepository metodoPagoRepository;

    public List<MetodoPago> findAll() {
        return metodoPagoRepository.findAll();
    }

    public MetodoPago findById(Long id) {
        Optional<MetodoPago> metodoPagoOptional = metodoPagoRepository.findById(id); 
        if (metodoPagoOptional.isPresent()) {
            return metodoPagoOptional.get(); 
        } else {
            throw new RuntimeException("Método de pago no disponible o inexistente"); 
        }
    }

    public MetodoPago save(MetodoPago metodoPago) {
        return metodoPagoRepository.save(metodoPago);
    }

    public void delete(Long id) {
        metodoPagoRepository.deleteById(id);
    }

    public MetodoPago patchMetodoPago(Long id, MetodoPago parcialMetodoPago){
        Optional<MetodoPago> metodoPagoOptional = metodoPagoRepository.findById(id);
        if (metodoPagoOptional.isPresent()) {
            
            MetodoPago metodoPagoToUpdate = metodoPagoOptional.get();
            
            if (parcialMetodoPago.getMetodo() != null) {
                metodoPagoToUpdate.setMetodo(parcialMetodoPago.getMetodo());    
            }

            return metodoPagoRepository.save(metodoPagoToUpdate);
        } else {
            return null; 
        }
    }

}
