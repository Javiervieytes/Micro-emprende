package com.microemprende.cl.micro_emprende.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microemprende.cl.micro_emprende.model.MetodoPago;
import com.microemprende.cl.micro_emprende.service.MetodoPagoService;

@RestController
@RequestMapping("/api/v1/metodospago")
public class MetodoPagoController {

    @Autowired
    private MetodoPagoService metodoPagoService;

    @GetMapping
    public ResponseEntity<List<MetodoPago>> listar(){
        List<MetodoPago> metodos = metodoPagoService.findAll();
        if(metodos.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(metodos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MetodoPago> buscar(@PathVariable Long id){
        try{
            MetodoPago metodo = metodoPagoService.findById(id);
            return ResponseEntity.ok(metodo);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<MetodoPago> guardar(@RequestBody MetodoPago metodoPago) {
        MetodoPago nuevoMetodo = metodoPagoService.save(metodoPago);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoMetodo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MetodoPago> actualizar(@PathVariable Long id, @RequestBody MetodoPago metodoPago){
        try{
            metodoPagoService.save(metodoPago);
            return ResponseEntity.ok(metodoPago);
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<MetodoPago> patchMetodoPago(@PathVariable Long id, @RequestBody MetodoPago parcialMetodoPago) {
        try {
            MetodoPago metodoActualizado = metodoPagoService.patchMetodoPago(id, parcialMetodoPago);
            return ResponseEntity.ok(metodoActualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            metodoPagoService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
