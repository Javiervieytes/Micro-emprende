package com.microemprende.cl.micro_emprende.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.ProductoVenta;
import com.microemprende.cl.micro_emprende.repository.ProductoVentaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductoVentaService {

    @Autowired
    private ProductoVentaRepository repository;

    public List<ProductoVenta> findAll() {
        return repository.findAll();
    }

    public ProductoVenta findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ProductoVenta no encontrada"));
    }

    public ProductoVenta save(ProductoVenta productoVenta) {
        return repository.save(productoVenta);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public ProductoVenta patch(Long id, ProductoVenta parcial) {
        ProductoVenta existente = findById(id);

        if (parcial.getCantidad() != null) {
            existente.setCantidad(parcial.getCantidad());
        }
        if (parcial.getPrecioUnitario() != null) {
            existente.setPrecioUnitario(parcial.getPrecioUnitario());
        }
        if (parcial.getProducto() != null) {
            existente.setProducto(parcial.getProducto());
        }
        if (parcial.getVenta() != null) {
            existente.setVenta(parcial.getVenta());
        }

        return repository.save(existente);
    }
}
