package com.microemprende.cl.micro_emprende.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microemprende.cl.micro_emprende.model.Vendedores;
import com.microemprende.cl.micro_emprende.repository.VendedoresRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class VendedoresService {

    @Autowired
    private VendedoresRepository vendedoresRepository;

    public List<Vendedores> findAll() {
        return vendedoresRepository.findAll();
    }

    public Vendedores findById(Long id) {
        Optional<Vendedores> optional = vendedoresRepository.findById(id);
        return optional.orElseThrow(() -> new RuntimeException("Vinculación de vendedor no encontrada"));
    }

    public Vendedores save(Vendedores vendedores) {
        return vendedoresRepository.save(vendedores);
    }

    public void delete(Long id) {
        vendedoresRepository.deleteById(id);
    }

    public Vendedores patchVendedores(Long id, Vendedores parcial) {
        Optional<Vendedores> optional = vendedoresRepository.findById(id);
        if (optional.isPresent()) {
            Vendedores toUpdate = optional.get();

            if (parcial.getVenta() != null) {
                toUpdate.setVenta(parcial.getVenta());
            }

            if (parcial.getVendedor() != null) {
                toUpdate.setVendedor(parcial.getVendedor());
            }

            return vendedoresRepository.save(toUpdate);
        } else {
            throw new RuntimeException("Vinculación de vendedor no encontrada");
        }
    }
}

