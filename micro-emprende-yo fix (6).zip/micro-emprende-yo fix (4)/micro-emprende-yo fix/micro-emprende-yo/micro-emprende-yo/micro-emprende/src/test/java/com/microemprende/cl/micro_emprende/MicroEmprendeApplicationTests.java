package com.microemprende.cl.micro_emprende;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroEmprendeApplicationTests {

	@Test
	void contextLoads() {
	}

}
